from django.contrib import admin
from .models import Turma

admin.site.register(Turma)
