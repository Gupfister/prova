from django.contrib import admin
from .models import Aluno

admin.site.register(Aluno)
